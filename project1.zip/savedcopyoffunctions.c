#include "functions.h"
#include <stdio.h>


/* Write your implementations of the functions in this source file.
 * Skeleton versions of the functions already appear below.
 */
/*long  power(int n, int num);*/

int has366(int y) {
  if(y % 4 == 0){
    if (y % 100 == 0){
      if(y % 400 == 0){

	return 1;
      } else{

	return 0;

      }

    }else{
      return 1;
    }

  }
return 0;
  
}

long sopd(int num, int n) {
  int i = 0;
  long temp = 1;
  long base =1;
int exp = n;
printf("initial: i: %d temp: %ld \n", i, temp);
  for( i=1; i <= num; i++){
printf("inside for loop: i: %d temp: %ld\n", i, temp);
   
    if(num % i == 0){
printf("inside if loop: i: %d temp: %ld\n", i, temp);
/*temp += power(i, n);*/
      while(exp!= 0 && i != 1){
printf("inside while loop: i: %d temp: %ld\n", i, temp);
         base *= i;
            --exp;
printf("base: %ld:\n", base);
      }
     exp = n;
if( base != 1){
     temp += base;
}
base = 1;
    
       
    }
    else{
printf("Does not work\n");
   }
   
}
printf("end: i: %d temp: %ld\n", i, temp);
    return temp;
  
}
/*long power(int num, int n) { 
     if (n == 0) 
        return 1; 
    else if (n%2 == 0) 
        return power(num, n/2)*power(num, n/2); 
    else
        return num*power(num, n/2)*power(num, n/2); 
	}*/


