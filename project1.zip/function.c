#include <stdio.h>

int has366(int year){

  if(year % 4 == 0){
    if (year % 100 == 0){
      if(year % 400 == 0){

	return 1;
      } else{

	return 0;

      }

    }

  }

  return 0;

}


long sopd(int num, int n){

  int i = 0;
  long temp = 1;

  for( i=0; i < num; i++){
    if(num % i  == 0){

      temp += pow(i,n);

    }
  
  }
			       
  printf("%lu", temp);

    return temp;
  

}
