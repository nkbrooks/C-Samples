/* (c) Larry Herman, 2020.  You are allowed to use this code yourself, but
 * not to provide it to anyone else. */

int has366(int y);
long sopd(int num, int n);
